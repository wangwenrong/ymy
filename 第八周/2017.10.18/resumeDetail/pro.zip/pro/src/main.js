import React from 'react';
import ReactDOM,{render} from 'react-dom';
import Routes from './routes';

//引入全局样式
import './main.css'


render(Routes,document.getElementById('app'));

