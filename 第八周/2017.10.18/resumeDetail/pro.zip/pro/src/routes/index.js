import React from 'react';
import {Router,Route,hashHistory,IndexRoute,Redirect,browserHistory} from 'react-router';

import App from '../App';
import About from '../About';
import Contact from '../Contact';
import Home from '../Home';

export default (
    <Router history={browserHistory}>
        <Route path="/" component={App}>
            <IndexRoute component={Home}/>
            <Route path="about" component={About}/>
            <Route path="contact" component={Contact}/>
           {/* <Route path="contact/:username/:pass" component={Contact}/>
            <Redirect from="contact" to="contact/haha/xixi"/>*/}
        </Route>
    </Router>
)
