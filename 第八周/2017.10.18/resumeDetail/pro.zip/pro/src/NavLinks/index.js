import React,{Component} from 'react';
import {Link} from 'react-router';
import './index.css';

export default class NavLinks extends Component{
    render(){
        let {to,linkname}=this.props;
        return(
            <li>
                <Link to={to} activeClassName="active">{linkname}</Link>
            </li>
        )
    }
}