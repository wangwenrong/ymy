import React,{Component} from 'react';
import {Link,IndexLink,browserHistory} from 'react-router';

import NavLinks from './NavLinks';
export default class App extends Component{
    handleSubmit(e){
        e.preventDefault();
        let username=e.target.elements[0].value;
        let pass=e.target.elements[1].value;
        let newPath=`/${username}/${pass}`;
        browserHistory.push(newPath)
    }
    goBack(){
        //console.dir(browserHistory)
        browserHistory.goBack();
    }
    render(){
        let data=[
            {path:'/about',name:'关于我们'},
            {path:'/contact',name:'联系我们'}
        ]
        return(
            <div>
                <h1>这是APP页面</h1>
                <ul>
                    <IndexLink to="/" activeStyle={{background:'green',fontSize:'30px',color:'#fff'}}>我是首页</IndexLink>
                    {data.map(item=>(
                        <NavLinks key={item.name} to={item.path} linkname={item.name}/>
                    ))}

                    <form onSubmit={this.handleSubmit}>
                        <input type="text" name="username" placeholder="请输入您的用户名"/>
                        <input type="password" name="pass" placeholder="password"/>
                        <button type="submit">提交数据</button>
                        <button type="button" onClick={this.goBack}>点击回退</button>
                    </form>
                </ul>
                {this.props.children}
            </div>
        )
    }
}