import React,{Component} from 'react';

export default class Home extends Component{
    render(){
        return(
            <div>
                <h1>我是首页!!~</h1>
            </div>
        )
    }
}