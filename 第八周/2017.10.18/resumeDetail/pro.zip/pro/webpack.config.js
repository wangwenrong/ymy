const path=require('path');
const webpack=require('webpack');
const ExtractTextWebpackPlugin=require('extract-text-webpack-plugin');
const HtmlWebPackPlugin=require('html-webpack-plugin');

module.exports={
    entry:'./src/main.js',
    output: {
        path:path.resolve(__dirname,'./dist'),
        filename: "bundle.js"
    },
    module:{
        rules:[
            {
                test:/\.js$/,
                loader:'babel-loader',
                exclude:/node_modules/
            },
            {
                test:/\.css$/,
                use: ExtractTextWebpackPlugin.extract({
                    fallback:'style-loader',
                    publicPath:'./dist',
                    use:'css-loader'
                })
            }
        ]
    },
    plugins: [
        new ExtractTextWebpackPlugin('styles.css'),
        new HtmlWebPackPlugin({
            template:'./src/index.html'
        })
    ]
};